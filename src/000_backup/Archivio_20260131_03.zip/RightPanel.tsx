import { CanvasObject } from './types'
import { IPE_CATALOG } from './profiles'

type Props = {
  selected: CanvasObject | null
  onChange: (patch: Partial<CanvasObject>) => void
}

export function RightPanel({ selected, onChange }: Props) {
  if (!selected) {
    return (
      <div className="right-panel empty">
        <p>Nessun oggetto selezionato</p>
      </div>
    )
  }

  if (selected.type === 'profile' && selected.profileType === 'IPE') {
        return (
        <div className="right-panel">
            <h3>Profilo IPE</h3>

            <label>
            Sezione
            <select
                value={selected.profileName}
                onChange={e =>
                onChange({ profileName: e.target.value })
                }
            >
                {IPE_CATALOG.map(p => (
                <option key={p.name} value={p.name}>
                    {p.name}
                </option>
                ))}
            </select>
            </label>

            <label>
            Scala
            <input
                type="number"
                step={0.1}
                value={selected.scale}
                onChange={e =>
                onChange({ scale: +e.target.value })
                }
            />
            </label>

            {'stroke' in selected && (
                <label>
                Stroke
                <input
                    type="color"
                    value={selected.stroke || '#000000'}
                    onChange={e => onChange({ stroke: e.target.value })}
                />
                </label>
            )}
            {'fillEnabled' in selected && (
                <label>
                Fill
                <input
                    type="checkbox"
                    checked={selected.fillEnabled}
                    onChange={e =>
                    onChange({ fillEnabled: e.target.checked })
                    }
                />
                </label>
            )}

            {selected.fillEnabled && (
                <label>
                Fill color
                <input
                    type="color"
                    value={selected.fillColor || '#cccccc'}
                    onChange={e =>
                    onChange({ fillColor: e.target.value })
                    }
                />
                </label>
            )}

            
        </div>
        )
    }


  return (
    <div className="right-panel">
      <h3>Oggetto: {selected.type}</h3>

      {'x' in selected && (
        <>
          <label>
            X
            <input
              type="number"
              value={selected.x}
              onChange={e => onChange({ x: +e.target.value })}
            />
          </label>

          <label>
            Y
            <input
              type="number"
              value={selected.y}
              onChange={e => onChange({ y: +e.target.value })}
            />
          </label>
        </>
      )}

      {'stroke' in selected && (
        <label>
          Stroke
          <input
            type="color"
            value={selected.stroke || '#000000'}
            onChange={e => onChange({ stroke: e.target.value })}
          />
        </label>
      )}

      {'fillEnabled' in selected && (
        <label>
          Fill
          <input
            type="checkbox"
            checked={selected.fillEnabled}
            onChange={e =>
              onChange({ fillEnabled: e.target.checked })
            }
          />
        </label>
      )}

      {selected.fillEnabled && (
        <label>
          Fill color
          <input
            type="color"
            value={selected.fillColor || '#cccccc'}
            onChange={e =>
              onChange({ fillColor: e.target.value })
            }
          />
        </label>
      )}
    </div>


  
  )
}