import { useEffect, useState } from 'react'
import { Canvas } from './Canvas'
import { Toolbar } from './Toolbar'
import { RightPanel } from './RightPanel'
import { CanvasObject } from './types'

type Point = { x: number; y: number }

export default function App() {
  const [objects, setObjects] = useState<CanvasObject[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [drawingPolyline, setDrawingPolyline] =
    useState<Point[] | null>(null)

  // 👉 stato pannello destro
  const [rightPanelWidth, setRightPanelWidth] = useState(320)
  const [resizing, setResizing] = useState(false)

  const selectedObject =
    objects.find(o => o.id === selectedId) || null

  // ======================
  // Resize panel handlers
  // ======================
  const onResizeMouseDown = () => {
    setResizing(true)
  }

  const onMouseMove = (e: MouseEvent) => {
    if (!resizing) return

    const newWidth = window.innerWidth - e.clientX
    const clamped = Math.min(Math.max(newWidth, 220), 600)
    setRightPanelWidth(clamped)
  }

  const onMouseUp = () => {
    setResizing(false)
  }

  useEffect(() => {
    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup', onMouseUp)

    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup', onMouseUp)
    }
  }, [resizing])

  // ======================
  // Update selected object
  // ======================
  const updateSelectedObject = (patch: Partial<CanvasObject>) => {
    if (!selectedId) return

    setObjects(objs =>
      objs.map(o =>
        o.id === selectedId ? { ...o, ...patch } : o
      )
    )
  }

  // ======================
  // Render
  // ======================
  return (
    <div className="app">
      <Toolbar
        setObjects={setObjects}
        setDrawingPolyline={setDrawingPolyline}
      />

      <div className="editor">
        <Canvas
          objects={objects}
          setObjects={setObjects}
          selectedId={selectedId}
          setSelectedId={setSelectedId}
          drawingPolyline={drawingPolyline}
          setDrawingPolyline={setDrawingPolyline}
        />

        <div
          className="right-panel"
          style={{ width: rightPanelWidth }}
        >
          <div
            className="resize-handle"
            onMouseDown={onResizeMouseDown}
          />

          <RightPanel
            selected={selectedObject}
            onChange={updateSelectedObject}
          />
        </div>
      </div>
    </div>
  )
}
