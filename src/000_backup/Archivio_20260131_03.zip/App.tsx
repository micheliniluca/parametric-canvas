import { useEffect, useState } from 'react'
import { Canvas } from './Canvas'
import { Toolbar } from './Toolbar'
import { RightPanel } from './RightPanel'
import { CanvasObject } from './types'

type Point = { x: number; y: number }

export default function App() {
  const [objects, setObjects] = useState<CanvasObject[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [drawingPolyline, setDrawingPolyline] =
    useState<Point[] | null>(null)

  /* ======================
     RIGHT PANEL STATE
     ====================== */
  const [rightPanelWidth, setRightPanelWidth] = useState(320)
  const [rightPanelOpen, setRightPanelOpen] = useState(true)
  const [resizingPanel, setResizingPanel] = useState(false)

  const RIGHT_PANEL_COLLAPSED = 80
  const RIGHT_PANEL_MIN = 200
  const RIGHT_PANEL_MAX = 500

  const selectedObject =
    objects.find(o => o.id === selectedId) || null

  /* ======================
     RESIZE EFFECT
     ====================== */
  useEffect(() => {
    if (!resizingPanel) return

    const onMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX
      setRightPanelWidth(
        Math.min(
          Math.max(newWidth, RIGHT_PANEL_MIN),
          RIGHT_PANEL_MAX
        )
      )
    }

    const onUp = () => setResizingPanel(false)

    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)

    return () => {
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
  }, [resizingPanel])

  /* ======================
     UPDATE OBJECT
     ====================== */
  const updateSelectedObject = (patch: Partial<CanvasObject>) => {
    if (!selectedId) return
    setObjects(objs =>
      objs.map(o =>
        o.id === selectedId ? { ...o, ...patch } : o
      )
    )
  }

  /* ======================
     RENDER
     ====================== */
  return (
    <div className="app">
      <Toolbar
        setObjects={setObjects}
        setDrawingPolyline={setDrawingPolyline}
      />

      <div className="main">
        {/* CANVAS */}
        <div className="canvas-viewport">
          <Canvas
            objects={objects}
            setObjects={setObjects}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            drawingPolyline={drawingPolyline}
            setDrawingPolyline={setDrawingPolyline}
          />
        </div>

        {/* RIGHT PANEL */}
        <div
          className="right-panel-container"
          style={{
            width: rightPanelOpen
              ? rightPanelWidth
              : RIGHT_PANEL_COLLAPSED,
          }}
        >
          {/* RESIZE HANDLE */}
          <div
            className="panel-resize-handle"
            onMouseDown={() => setResizingPanel(true)}
          />

          {/* COLLAPSE BUTTON */}
          <button
            className="collapse-btn"
            onClick={() => setRightPanelOpen(v => !v)}
          >
            {rightPanelOpen ? '⮜' : '⮞'}
          </button>

          {/* PANEL CONTENT */}
          {rightPanelOpen && (
            <RightPanel
              selected={selectedObject}
              onChange={updateSelectedObject}
            />
          )}
        </div>
      </div>
    </div>
  )
}
