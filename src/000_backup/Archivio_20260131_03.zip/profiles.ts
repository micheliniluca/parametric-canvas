export type IPEProfile = {
  name: string
  h: number   // altezza
  b: number   // larghezza ala
  tw: number  // spessore anima
  tf: number  // spessore ala
}

export const IPE_CATALOG: IPEProfile[] = [
  { name: 'IPE 100', h: 100, b: 55, tw: 4.1, tf: 5.7 },
  { name: 'IPE 200', h: 200, b: 100, tw: 5.6, tf: 8.5 },
  { name: 'IPE 300', h: 300, b: 150, tw: 6.5, tf: 10.7 },
]