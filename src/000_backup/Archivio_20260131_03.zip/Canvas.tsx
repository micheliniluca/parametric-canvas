import { CanvasObject } from './types'
import { Dispatch, SetStateAction, useRef, useState } from 'react'
import { IPE_CATALOG } from './profiles'

const GRID_SIZE = 50
const GRID_EXTENT = 5000
const DRAG_THRESHOLD = 6

type Point = { x: number; y: number }

type Props = {
  objects: CanvasObject[]
  setObjects: Dispatch<SetStateAction<CanvasObject[]>>
  selectedId: string | null
  setSelectedId: (id: string | null) => void

  // polyline in costruzione
  drawingPolyline: Point[] | null
  setDrawingPolyline: Dispatch<SetStateAction<Point[] | null>>
}

export function Canvas({
  objects,
  setObjects,
  selectedId,
  setSelectedId,
  drawingPolyline,
  setDrawingPolyline,
}: Props) {


    /* ======================
     CAMERA (PAN)
     ====================== */
  const [view, setView] = useState({ x: 0, y: 0 })
  const panRef = useRef<{
    startX: number
    startY: number
    viewX: number
    viewY: number
  } | null>(null)

    /* ======================
     DRAG OGGETTI
     ====================== */
  const dragRef = useRef<{
    id: string
    startX: number
    startY: number
    offsetX: number
    offsetY: number
    active: boolean
  } | null>(null)

  const resizeRef = useRef<{
    id: string
    corner: 'tl' | 'tr' | 'bl' | 'br'
  } | null>(null)

  const polylineGripRef = useRef<{
    id: string
    index: number
  } | null>(null)


  const snap = (v: number, step: number) =>
    Math.round(v / step) * step

  const getSvgPoint = (
    e: React.MouseEvent<SVGSVGElement, MouseEvent>
  ) => {
    const svg = e.currentTarget
    const pt = svg.createSVGPoint()
    pt.x = e.clientX
    pt.y = e.clientY
    return pt.matrixTransform(svg.getScreenCTM()!.inverse())
  }
  /* ======================
     MOUSE DOWN SU OGGETTO
     ====================== */
  const onObjectMouseDown = (e: React.MouseEvent, o: CanvasObject) => {
    e.stopPropagation()
    setSelectedId(o.id)

    const refPoint =
      o.type === 'polyline'
        ? o.points[0]
        : o

    dragRef.current = {
      id: o.id,
      startX: e.clientX,
      startY: e.clientY,
      offsetX: e.clientX - refPoint.x,
      offsetY: e.clientY - refPoint.y,
      active: false,
    }
  }



 const onMouseMove = (
  e: React.MouseEvent<SVGSVGElement, MouseEvent>
) => {




    if (panRef.current) {
      const dx = e.clientX - panRef.current.startX
      const dy = e.clientY - panRef.current.startY

      setView({
        x: panRef.current.viewX - dx,
        y: panRef.current.viewY - dy,
      })
      return
    }

    if (resizeRef.current) {
      const { id, corner } = resizeRef.current

      setObjects(objs =>
        objs.map(o => {
          if (o.id !== id || o.type !== 'rect') return o

          let { x, y, width, height } = o

          if (corner === 'tl') {
            width += x - e.clientX
            height += y - e.clientY
            x = e.clientX
            y = e.clientY
          }
          if (corner === 'tr') {
            width = e.clientX - x
            height += y - e.clientY
            y = e.clientY
          }
          if (corner === 'bl') {
            width += x - e.clientX
            x = e.clientX
            height = e.clientY - y
          }
          if (corner === 'br') {
            width = e.clientX - x
            height = e.clientY - y
          }

          return {
            ...o,
            x,
            y,
            width: Math.max(5, width),
            height: Math.max(5, height),
          }
        })
      )
      return
    }

    if (polylineGripRef.current) {
      const { id, index } = polylineGripRef.current
      const p = getSvgPoint(e as any)

      setObjects(objs =>
        objs.map(o => {
          if (o.id !== id || o.type !== 'polyline') return o

          const pts = o.points
          const lastIndex = pts.length - 1

          const isClosed =
            pts.length > 2 &&
            pts[0].x === pts[lastIndex].x &&
            pts[0].y === pts[lastIndex].y

          const newPoints = pts.map((pt, i) => {
            // punto trascinato
            if (i === index) {
              return { x: p.x, y: p.y }
            }

            // se chiusa: sincronizza primo ↔ ultimo
            if (isClosed) {
              if (index === 0 && i === lastIndex) {
                return { x: p.x, y: p.y }
              }
              if (index === lastIndex && i === 0) {
                return { x: p.x, y: p.y }
              }
            }

            return pt
          })

          return { ...o, points: newPoints }

        })
      )
      return
    }


    if (!dragRef.current) return
    const d = dragRef.current

    const dx = Math.abs(e.clientX - d.startX)
    const dy = Math.abs(e.clientY - d.startY)

    if (!d.active && dx + dy > DRAG_THRESHOLD) {
      d.active = true
    }

    if (!d.active) return

    const rawX = e.clientX - d.offsetX
    const rawY = e.clientY - d.offsetY
    const doSnap = e.shiftKey

    const finalX = doSnap ? snap(rawX, GRID_SIZE) : rawX
    const finalY = doSnap ? snap(rawY, GRID_SIZE) : rawY

    setObjects(objs =>
      objs.map(o => {
        if (o.id !== d.id) return o

        if (o.type === 'polyline') {
          const dx = finalX - o.points[0].x
          const dy = finalY - o.points[0].y

          return {
            ...o,
            points: o.points.map(p => ({
              x: p.x + dx,
              y: p.y + dy,
            })),
          }
        }

        return { ...o, x: finalX, y: finalY }
      })
    )

  }

  const onMouseUp = () => {
    dragRef.current = null
    resizeRef.current = null
    polylineGripRef.current = null
    panRef.current = null

  }

  const gridLines = []
  for (let x = 0; x <= GRID_EXTENT; x += GRID_SIZE) {
    gridLines.push(
      <line
        key={`gx-${x}`}
        x1={x}
        y1={0}
        x2={x}
        y2={GRID_EXTENT}
        stroke="#e5e5e5"
        strokeWidth={1}
      />
    )
  }
  for (let y = 0; y <= GRID_EXTENT; y += GRID_SIZE) {
    gridLines.push(
      <line
        key={`gy-${y}`}
        x1={0}
        y1={y}
        x2={GRID_EXTENT}
        y2={y}
        stroke="#e5e5e5"
        strokeWidth={1}
      />
    )
  }

  return (
    <svg
      className="canvas"
      width="100%"
      height="100%"
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onMouseDown={e => {
        if (e.target === e.currentTarget) {
          setSelectedId(null)
          panRef.current = {
            startX: e.clientX,
            startY: e.clientY,
            viewX: view.x,
            viewY: view.y,
          }
        }
      }}

      onClick={e => {
        if (!drawingPolyline) return
        if (e.detail > 1) return // ⛔ ignora il click del doppio click


        const p = getSvgPoint(e)
        setDrawingPolyline(prev =>
        prev ? [...prev, { x: p.x, y: p.y }] : prev
        )
        }}
      onDoubleClick={e => {
        e.stopPropagation()

        if (!drawingPolyline || drawingPolyline.length < 2) return

        const first = drawingPolyline[0]
        const closed = [...drawingPolyline, first]
        const newId = crypto.randomUUID()

        setObjects(objs => [
          ...objs,
          {
            id: newId,
            type: 'polyline',
            points: closed,
            stroke: '#000000',
            fillEnabled: false,
            fillColor: 'transparent',
          },
        ])

  // esci dalla modalità disegno
  setDrawingPolyline(null)
  setSelectedId(newId)
}}
    >

      <g transform={`translate(${-view.x}, ${-view.y})`}>
      {/* griglia */}
      <g pointerEvents="none">{gridLines}</g>

      {/* polyline in costruzione */}
      {drawingPolyline && (
        <polyline
          points={drawingPolyline.map(p => `${p.x},${p.y}`).join(' ')}
          fill="none"
          stroke="red"
          strokeWidth={2}
          pointerEvents="none"
        />
      )}

      {drawingPolyline &&
        drawingPolyline.map((p, i) => (
          <circle
            key={`drawing-grip-${i}`}
            cx={p.x}
            cy={p.y}
            r={5}
            fill="white"
            stroke="red"
            strokeWidth={2}
            pointerEvents="none"
          />
        ))}

      {/* oggetti */}
      {objects.map(o => {
        const isSelected = o.id === selectedId
        const fillValue = o.fillEnabled ? o.fillColor || '#ccc' : 'transparent'
        const strokeValue = isSelected ? 'orange' : o.stroke || 'black'
        const strokeWidth = isSelected ? 3 : 1

      if (o.type === 'rect') {
        return (
          <g key={o.id}>
            {/* Rettangolo */}
            <rect
              x={o.x}
              y={o.y}
              width={o.width}
              height={o.height}
              fill={fillValue}
              stroke={strokeValue}
              strokeWidth={strokeWidth}
              onMouseDown={e => onObjectMouseDown(e, o)}
            />

            {/* Grip di resize (solo se selezionato) */}
            {isSelected && (
              <>
                {([
                  { x: o.x, y: o.y, corner: 'tl' },
                  { x: o.x + o.width, y: o.y, corner: 'tr' },
                  { x: o.x, y: o.y + o.height, corner: 'bl' },
                  { x: o.x + o.width, y: o.y + o.height, corner: 'br' },
                ] as const).map(h => (
                  <circle
                    key={h.corner}
                    cx={h.x}
                    cy={h.y}
                    r={6}
                    fill="white"
                    stroke="black"
                    strokeWidth={1}
                    cursor="nwse-resize"
                    onMouseDown={e => {
                      e.stopPropagation()
                      resizeRef.current = {
                        id: o.id,
                        corner: h.corner,
                      }
                    }}
                  />
                ))}
              </>
            )}
          </g>
        )
      }


      if (o.type === 'polyline') {
        const fillValue =
          o.fillEnabled && o.fillColor ? o.fillColor : 'none'

        const pointerMode =
          o.fillEnabled && fillValue !== 'none'
            ? 'all'
            : 'stroke'

        return (
          <g key={o.id}>
            {/* Polyline */}
            <polyline
              points={o.points.map(p => `${p.x},${p.y}`).join(' ')}
              fill={fillValue}
              stroke={strokeValue}
              strokeWidth={isSelected ? 4 : 2}
              pointerEvents={pointerMode}
              onMouseDown={e => {
                e.stopPropagation()
                onObjectMouseDown(e, o)
              }}
            />

            {/* Grip sui vertici */}
            {isSelected &&
              o.points.map((p, i) => (
                <circle
                  key={i}
                  cx={p.x}
                  cy={p.y}
                  r={6}
                  fill="white"
                  stroke="black"
                  strokeWidth={1}
                  cursor="move"
                  onMouseDown={e => {
                    e.stopPropagation()
                    polylineGripRef.current = {
                      id: o.id,
                      index: i,
                    }
                  }}
                />
              ))}
          </g>
        )
      }





        if (o.type === 'circle') {
          return (
            <circle
              key={o.id}
              cx={o.x}
              cy={o.y}
              r={o.radius}
              fill={fillValue}
              stroke={strokeValue}
              strokeWidth={strokeWidth}
              onMouseDown={e => onObjectMouseDown(e, o)}
            />
          )
        }

        if (o.type === 'profile' && o.profileType === 'IPE') {
          const profile = IPE_CATALOG.find(p => p.name === o.profileName)
          if (!profile) return null
          const { h, b, tw, tf } = profile
          const s = o.scale
          const x0 = o.x
          const y0 = o.y

          return (
            <g key={o.id} onMouseDown={e => onObjectMouseDown(e, o)}>
              <rect
                x={x0 - (b * s) / 2}
                y={y0 - (h * s) / 2}
                width={b * s}
                height={tf * s}
                fill={fillValue}
                stroke={strokeValue}
              />
              <rect
                x={x0 - (tw * s) / 2}
                y={y0 - (h * s) / 2 + tf * s}
                width={tw * s}
                height={(h - 2 * tf) * s}
                fill={fillValue}
                stroke={strokeValue}
              />
              <rect
                x={x0 - (b * s) / 2}
                y={y0 + (h * s) / 2 - tf * s}
                width={b * s}
                height={tf * s}
                fill={fillValue}
                stroke={strokeValue}
              />
            </g>
          )
        }

        return null
      })}
      </g>
    </svg>
  )
}