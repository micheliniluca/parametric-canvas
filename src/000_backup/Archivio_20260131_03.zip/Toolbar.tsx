import { Dispatch, SetStateAction } from 'react'
import { CanvasObject } from './types'
import { IPE_CATALOG } from './profiles'
import { useState, useEffect } from 'react'


type Point = { x: number; y: number }

type Props = {
  setObjects: Dispatch<SetStateAction<CanvasObject[]>>
  setDrawingPolyline: Dispatch<SetStateAction<Point[] | null>>
}

export function Toolbar({
  setObjects,
  setDrawingPolyline,
}: Props) {
  const addRect = () =>
    setObjects(o => [
      ...o,
      {
        id: crypto.randomUUID(),
        type: 'rect',
        x: 50,
        y: 50,
        width: 100,
        height: 60,
        stroke: '#000000',
        fillEnabled: false,
        fillColor: '#ff0000',
      },
    ])

  const addCircle = () =>
    setObjects(o => [
      ...o,
      {
        id: crypto.randomUUID(),
        type: 'circle',
        x: 200,
        y: 100,
        radius: 40,
        stroke: '#000000',
        fillEnabled: false,
        fillColor: '#cccccc',
      },
    ])

  const addText = () =>
    setObjects(o => [
      ...o,
      {
        id: crypto.randomUUID(),
        type: 'text',
        x: 100,
        y: 200,
        text: 'Testo',
        stroke: '#000000',
      },
    ])

  const addIPE = () =>
    setObjects(o => [
      ...o,
      {
        id: crypto.randomUUID(),
        type: 'profile',
        profileType: 'IPE',
        profileName: 'IPE 200',
        x: 200,
        y: 200,
        scale: 1,
        stroke: '#000000',
        fillEnabled: true,
        fillColor: '#cccccc',
      },
    ])

  const startPolyline = () => {
    // entra in modalità disegno
    setDrawingPolyline([])
  }

  const [selectedIPE, setSelectedIPE] = useState(
    IPE_CATALOG[0].name
  )

  const addIPEProfile = () => {
    setObjects(objs => [
      ...objs,
      {
        id: crypto.randomUUID(),
        type: 'profile',
        profileType: 'IPE',
        profileName: 'IPE100', // 🔥 QUI
        x: 300,
        y: 300,
        scale: 1,
        stroke: '#000',
        fillEnabled: false,
      },
    ])
  }




  return (
    <div className="toolbar">
      <button onClick={addRect}>Rettangolo</button>
      <button onClick={addCircle}>Cerchio</button>
      <button onClick={addText}>Testo</button>
      <button onClick={addIPE}>IPE</button>
      <button onClick={startPolyline}>Polyline</button>
    


    
    </div>
  )
}