export type BaseObject = {
  id: string
  type: 'rect' | 'circle' | 'text' | 'profile'
  x: number
  y: number
  stroke?: string
  fillColor?: string
  fillEnabled?: boolean
}

export type RectObject = BaseObject & {
type: 'rect'
width: number
height: number
}


export type CircleObject = BaseObject & {
type: 'circle'
radius: number
}


export type TextObject = BaseObject & {
type: 'text'
text: string
}

export type ProfileObject = BaseObject & {
  type: 'profile'
  profileType: 'IPE'
  profileName: string
  scale: number
  
}

export type PolylineObject = {
  id: string
  type: 'polyline'
  points: { x: number; y: number }[]
  closed: boolean
  stroke: string
  fillEnabled: boolean
  fillColor?: string
}

export type CanvasObject = RectObject | CircleObject | TextObject | ProfileObject | PolylineObject

fillColor: '#cccccc'
fillEnabled: false
